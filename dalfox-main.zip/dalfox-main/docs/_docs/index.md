---
title: Welcome
permalink: /docs/home/
redirect_from: /docs/index.html
---

> Finder Of XSS, and Dal is the Korean pronunciation of moon.

DalFox is a powerful open source XSS scanning tool and parameter analyzer and utility that fast the process of detecting and verify XSS flaws. It comes with a powerful testing engine, many niche features for the cool hackers. I talk about naming. Dal(달) is the Korean pronunciation of moon and Fox was made into Fox (Finder Of XSS).

![](https://user-images.githubusercontent.com/13212227/120111056-4b30f480-c1ab-11eb-90a4-c831ccf76e11.jpg)
