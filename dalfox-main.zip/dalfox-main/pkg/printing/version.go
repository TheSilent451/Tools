package printing

// VERSION is version of dalfox
const VERSION = "v2.9.3"
