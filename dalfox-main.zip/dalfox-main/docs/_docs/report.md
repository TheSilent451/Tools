---
title: Report
permalink: /docs/report/
---

```shell
dalfox url https://xss-game.appspot.com/level1/frame --report
```

![](https://user-images.githubusercontent.com/13212227/190555379-a4b06b07-0ae0-4f9a-859a-650ac34186ae.png)

```shell
dalfox url https://xss-game.appspot.com/level1/frame --report --report-format json
```

![](https://user-images.githubusercontent.com/13212227/190555382-cb7e37b9-b4c9-4c99-b853-ff65a1df9e01.png)