---
title: For CI/CD Pipeline
permalink: /docs/tips/cicd/
---

## Use Github Action
[Dalfox in github marketplace](https://github.com/marketplace/actions/xss-scan-with-dalfox)

## Use REST API Server
[/docs/modes/server-mode/](/docs/modes/server-mode/)
